package com.neosoft.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class AuthenticationRequest implements Serializable {

    private String usn;
    private String pwd;

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    //need default constructor for JSON Parsing
    public AuthenticationRequest()
    {

    }

    public AuthenticationRequest(String usn, String pwd) {
        this.setUsn(usn);
        this.setPwd(pwd);
    }

	
}
