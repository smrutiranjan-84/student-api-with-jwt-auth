package com.neosoft.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name="User_Login")
public class UserLogin {
	
	@Id
	@NotNull
	@Column(name="uId")
	String userId;
	
	@NotNull
	@Column(name="uName")
	String userName;
	
	@NotNull
	@Column(name="pwd")
	String password;

}