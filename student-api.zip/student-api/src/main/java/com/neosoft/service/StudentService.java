package com.neosoft.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neosoft.model.Student;
import com.neosoft.repository.ProjectRepository;
import com.neosoft.repository.StudentRepository;
@Service
public class StudentService {
	
	@Autowired 
	StudentRepository studentRepository;
	

	@Autowired 
	ProjectRepository projecttRepository;
	
	public Student registerStudent(Student student){
		
		projecttRepository.saveAll(student.getProject());
		return studentRepository.save(student);
	}
	
    public ArrayList<Student> getAll(){
		
		return (ArrayList<Student>) studentRepository.findAll();
	}

    
    public Optional<Student> getStudentById(String id){
		
		return studentRepository.findById(id);
	}

}
